RAG1-AgentFlow-Analysis-Full

This archive contains a representative, corpus-grounded output of the proposed AgentFlow methodology applied to the dynamic OSINT collection RAG1-eng.docx.

Files:
- Executive_Report.pdf: concise management-level summary.
- Analytical_Report.pdf: full analytical report.
- Executive_Report.md: editable Markdown summary.
- Analytical_Report.md: full GitHub-friendly Markdown report.
- Analytical_Report.json: structured machine-readable result.
- semantic_graph.graphml: graph representation for graph tools.
- semantic_graph.gexf: Gephi-compatible graph representation.
- README.txt: archive description.

Important limitation:
Exact TF, DF, SF, IF, AF_eff, Z, Q, Delta_E, and Delta_R values were not fabricated. The package preserves qualitative confidence and epistemic status where repeatable machine execution data were unavailable.
